AgriNexa for Windows
An app by TerraSync Software Development Services

How to install
1. Unzip this folder (right-click the zip > Extract All).
2. Double-click the AgriNexa setup file.
3. Windows may show "Windows protected your PC" because the installer is not code-signed yet.
   Click "More info", then "Run anyway".
4. AgriNexa is added to the Start menu.

Needs Windows 10 or 11. The 3D models need an internet connection the first time.
Your progress is saved on this computer only. To remove the app: Settings > Apps > AgriNexa > Uninstall.

Reminders and the streak widget
- Closing the AgriNexa window keeps it running next to the clock (system tray) so your daily study reminder can arrive.
- Left-click the tray icon to open AgriNexa. Right-click it for "Streak widget" (a small always-on-top card) or "Quit AgriNexa".
- Set the reminder time in AgriNexa → Profile → Settings → Study reminders & widgets.
